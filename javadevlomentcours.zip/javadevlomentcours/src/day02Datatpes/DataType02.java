package day02Datatpes;

public class DataType02 {
    public static void main(String[] args) {

        int a=5,b=2;

        System.out.println(a/b);
        char ch ='%';
        System.out.println(ch+1);

        double m=5;
        int n=2;
        System.out.println(m/n);// the largest is show on the screen

        // in how many you can fix the issue
        //1 way
        float u=2.5f;
        //2 way
        double z=2.5;
        System.out.println(2+3+"ali");
        System.out.println(2+'a'+(3+4));

    }
}
