package JAVA_LESSON_TOTURAIL.ListParactice;

import java.util.ArrayList;
import java.util.List;

public class CreateArrayList {

    //How to create an ArrayList
    public static void main(String[] args) {

            List<Integer> list1 = new ArrayList<>();
            ArrayList<Integer> list2=new ArrayList<>();
            ArrayList<Integer> list3=new ArrayList<Integer>();


    }
}
