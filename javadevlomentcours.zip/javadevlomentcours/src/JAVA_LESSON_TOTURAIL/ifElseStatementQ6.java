package JAVA_LESSON_TOTURAIL;

public class ifElseStatementQ6 {

        public static void main(String[] args) {

        /*
        Type java code by using if-else statement,
            if the password is “JavaLearner”, output will be “The password is true”.
            Otherwise, output will be “The password is false”.
         */
            String pw="JavaLearner";
            if (pw.equals("JavaLearner")){
                System.out.println("The password is true");
            }else {
                System.out.println("The password is false");
            }
        }
    }


