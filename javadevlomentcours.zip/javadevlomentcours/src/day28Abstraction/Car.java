package day28Abstraction;

public abstract class Car {

        public abstract void make();
        public abstract void model();
        public abstract void year();

}
