package day21varargsstringbulideraccessmodifires;

public class StudentRunner {

    public static void main(String[] args) {

        Student std1=new Student();
        Parent p1=new Parent();




    }
}
