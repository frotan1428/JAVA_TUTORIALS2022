package JAVA_LESSON_TOTURAIL;

public class Control {


}
