package JAVA_LESSON_TOTURAIL.ForLoop;

public class Q08 {

     /*

         Write a program to print counting numbers which are less than 200 and divisible by 5
         On the console by using for-loop.
      */
    public static void main(String[] args) {
        for (int i=1;i<200;i++){

            if (i%5==0){
                System.out.println(i+" ");
            }

        }


    }
}
