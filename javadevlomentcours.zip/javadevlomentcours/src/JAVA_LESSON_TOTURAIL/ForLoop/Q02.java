package JAVA_LESSON_TOTURAIL.ForLoop;

public class Q02 {
    public static void main(String[] args) {

        //increase value
        for (int i=1; i<5;i++){
            System.out.println(i+ "");
        }
    }
}
