package JAVA_LESSON_TOTURAIL.Ternary;

public class Q03 {
    public static void main(String[] args) {

        int y = 7;
        int x = (y < 5) ? (2 * y) : (3 * y);
        System.out.println(x);
    }
}
