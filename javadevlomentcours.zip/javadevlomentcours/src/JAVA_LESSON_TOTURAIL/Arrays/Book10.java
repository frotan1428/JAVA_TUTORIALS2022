package JAVA_LESSON_TOTURAIL.Arrays;

import java.util.Arrays;

public class Book10 {

    //How to use binarySearch() in Arrays Class
    public static void main(String[] args) {

        int number[]={2,4,5,6,7,8,9};
        System.out.println(Arrays.binarySearch(number,4));
        System.out.println(Arrays.binarySearch(number,8));

    }
}
