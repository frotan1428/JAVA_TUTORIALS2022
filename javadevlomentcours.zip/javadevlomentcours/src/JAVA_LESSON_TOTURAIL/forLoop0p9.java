package JAVA_LESSON_TOTURAIL;

public class forLoop0p9 {

    public static void main(String[] args) {

        //Type java code by using for loop,
        //Write a program to print numbers from 1 to 5.
        for (int i=1;i<5; i+=1){

            System.out.println(i+ "");

        }


    }
}
