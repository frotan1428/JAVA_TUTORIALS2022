package day24ObjectManipulation;

public class Person {
  public String name;
    public String lastName;
    private int id;
    private int age;
    private double salary;

    public Person(){

    }
     public Person(String name,String lastName){

       this.name=name;
        this.lastName=lastName;

     }
/*
    public static void main(String[] args) {

        Person person=new Person("Hafasa","Muslesh");

        System.out.println(person.name);
        System.out.println(person.lastName);

    }
    */

}
