package day05ifeslestaements;

public class ifesle01 {
    public static void main(String[] args) {

       /*
        boolean car=true;
        boolean bus= false;
        if (car || bus){
            System.out.println("I can travel");

        */
        boolean cashmoney=false;
        boolean dibit= false;
        if (cashmoney || dibit){
            System.out.println("yes you can buy");
        }else{
            System.out.println("yes you can not buy");
        }

        }
    }

