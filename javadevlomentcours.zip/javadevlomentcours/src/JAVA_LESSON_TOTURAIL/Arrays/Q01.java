package JAVA_LESSON_TOTURAIL.Arrays;

import java.util.Arrays;

public class Q01 {

    public static void main(String[] args) {
        //  how To Create array
         String s=" i liked ti move it move it";
         String arr[]=s.split(" ");
        System.out.println(Arrays.toString(arr));

    }
}
