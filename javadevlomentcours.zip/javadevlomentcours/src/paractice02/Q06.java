package paractice02;

public class Q06 {
    public static void main(String[] args) {

        /*

            print on the console numbers from 1-100
            But do not use any Number in your code
         */
        int n='b'-'a';
        int m='d';
        System.out.println(n);
        for (int i=n;i<'e'; i++ ){
            System.out.println(i);
        }

        /*
        while (n<=m){
            System.out.print(n+" ");
            n++;
        }
         */
    }
}
