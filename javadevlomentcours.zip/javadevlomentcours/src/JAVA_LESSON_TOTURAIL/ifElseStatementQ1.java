package JAVA_LESSON_TOTURAIL;

public class ifElseStatementQ1 {

    public static void main(String[] args) {

        int a=-12;
        if (a<0){
            System.out.println("this is a positive Number");
        }else{
            System.out.println("this is a negative number");
        }


    }
}
