package day28Abstraction;

public abstract  class Animal {

    /*
        Create animalSound abstract Method
         Create animalName abstract Method
     */
    public abstract void animalSound();
    public abstract void animalName();


}
