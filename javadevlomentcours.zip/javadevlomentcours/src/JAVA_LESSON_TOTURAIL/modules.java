package JAVA_LESSON_TOTURAIL;

public class modules {

    public static void main(String[] args) {

        int a=20;
        int b=10;
        int c= a%b;
        System.out.println(c);

        int num1=45;
        int num2=13;
        int remainder=num1%num2;
        System.out.println("The Remainder is:"+remainder);

    }
}
