package day28Abstraction2;

public abstract  class Calculator {

    public abstract int addition(int n1,int n2);
    public abstract int multiplication(int n1,int n2);
    public abstract int subtraction(int n1,int n2);
    public abstract int division(int n1,int n2);


}
