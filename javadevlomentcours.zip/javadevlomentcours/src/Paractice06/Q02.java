package Paractice06;

public class Q02 {

//    String s1 = "java";
//    StringBuilder s2 = new StringBuilder("java");
//        if(s1 == s2){
//        System.out.println("1");
//    }
//        if(s1.equals(s2)){
//        System.out.println("2");
//    }

        /*
        A. 1
        B. 2
        C. 12
        D. No output is printed
        E. Gives error
         */

}
