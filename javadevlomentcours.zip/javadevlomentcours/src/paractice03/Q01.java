package paractice03;

public class Q01 {

    public static void main(String[] args) {

        //OCA Question
        int num = 10;
        do {
            System.out.print(num-- + " " + num);
        } while (num == 10);
        /*
         * // What is the result?
         * A) 9876543210
         * B) 9
         * C) 421
         * D) 9 10
         * E) Nothing is printed
         * F) 10 9
         */

    }

}
