package JAVA_LESSON_TOTURAIL;

public class CalculatorRunner {

    public static void main(String[] args) {

        Calculator cal=new Calculator();
        cal.add(12,12);
        cal.subtract(13,12);
        cal.division(10,5);
        cal.Product(12,60);

    }
}
