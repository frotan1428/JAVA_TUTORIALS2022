package JAVA_LESSON_TOTURAIL.Ternary;

public class Q01 {
    public static void main(String[] args) {

        int y = 3;
        System.out.println((y > 5) ? (2 * y) : (3 * y));
    }
}
