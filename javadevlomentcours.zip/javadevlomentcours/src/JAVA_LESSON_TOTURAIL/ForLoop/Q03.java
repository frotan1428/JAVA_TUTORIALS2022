package JAVA_LESSON_TOTURAIL.ForLoop;

public class Q03 {


    //Write a program to print counting numbers from 10 to 57 on the console by using for-loop.
    public static void main(String[] args) {
        for (int i=10;i<66;i++){
            System.out.println(i+" ");
        }


    }
}
