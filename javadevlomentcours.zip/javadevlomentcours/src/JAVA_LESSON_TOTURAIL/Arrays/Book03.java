package JAVA_LESSON_TOTURAIL.Arrays;

public class Book03 {

    //How to access the elements of an Array
    public static void main(String[] args) {

        int myArray[]={12,13,14};
        System.out.println(myArray[2]);//14

    }
}
