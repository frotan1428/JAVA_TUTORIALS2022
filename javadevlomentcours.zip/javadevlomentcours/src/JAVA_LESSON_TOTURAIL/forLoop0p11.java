package JAVA_LESSON_TOTURAIL;

public class forLoop0p11 {
    public static void main(String[] args) {
        int total=0;
        for (int i=1;i<5;i+=1){

            System.out.print(i+ " ");
            total+=i;
        }
        System.out.println(total);

    }

}
