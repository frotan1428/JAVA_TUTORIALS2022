package JAVA_LESSON_TOTURAIL;

public class day1902 {


    public static void main(String[] args) {

        for (int i=1;i<4;i++){
            for (int k=3;k>1;k--){

                System.out.println(i+"==>"+k);
            }
        }
    }
}
