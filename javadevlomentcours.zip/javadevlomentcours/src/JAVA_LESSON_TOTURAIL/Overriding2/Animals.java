package JAVA_LESSON_TOTURAIL.Overriding2;

public class Animals {



    public  void eat(){
       System.out.println("Animals eat");
   }
   public void drink(){
       System.out.println("Animals drink");
   }
}
