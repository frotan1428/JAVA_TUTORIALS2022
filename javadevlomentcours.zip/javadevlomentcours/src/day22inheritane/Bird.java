package day22inheritane;

public class Bird extends Animal{

    public void tweet(){
        System.out.println("Birds tweet...");
    }

}

