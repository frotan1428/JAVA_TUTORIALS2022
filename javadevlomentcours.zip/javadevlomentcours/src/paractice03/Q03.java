package paractice03;

public class Q03 {

    /*
       Create a method and
        from a given array find all pairs whose sum is a given number,
        {4,6,5,-10,8,5,20} ===> 10
        4 + 6 = 10
              5 + 5 = 10
             -10 + 20 = 10
        */

    int array [] = {4,6,5,-10,8,5,20};

    public static void main(String[] args) {




    }
}
