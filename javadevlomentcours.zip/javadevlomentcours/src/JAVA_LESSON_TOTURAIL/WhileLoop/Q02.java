package JAVA_LESSON_TOTURAIL.WhileLoop;

public class Q02 {


            /*
            Type java code by using while loop,
               Write a program to print numbers from 1 to 10.
             */
    public static void main(String[] args) {
         int i=1;
         while (i<11){
             System.out.println(i+" ");
             i++;
         }


    }
}
