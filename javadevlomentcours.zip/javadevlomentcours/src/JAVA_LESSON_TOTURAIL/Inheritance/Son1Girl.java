package JAVA_LESSON_TOTURAIL.Inheritance;

public class Son1Girl extends Son1{
}
