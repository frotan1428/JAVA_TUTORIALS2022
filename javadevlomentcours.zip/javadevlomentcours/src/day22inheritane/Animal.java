package day22inheritane;

public class Animal {


    public void eat(){
        System.out.println("Animals eat...");
    }

    public void drink(){
        System.out.println("Animals drink...");
    }

    public Animal(){
        System.out.println("Animal constructor");
    }
}
