package JAVA_LESSON_TOTURAIL.WhileLoop;

public class A {
    public A(int a){

    }
    public A(){

    }

}

