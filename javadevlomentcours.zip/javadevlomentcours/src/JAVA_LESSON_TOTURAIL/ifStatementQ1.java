package JAVA_LESSON_TOTURAIL;

public class ifStatementQ1 {

    public static void main(String[] args) {

    int a=6;
        /*

        Type java code, if an integer is even, output will be “The integer is even”.
        If the integer is odd, output will be “The integer is odd”.
         */
        if(a%2==0){
            System.out.println("The integer is even");
        }
        if (a%2!=0){
            System.out.println("The integer is odd");
        }
    }

}
