package day16Split;

import java.util.Arrays;

public class Split01 {
    public static void main(String[] args) {

        String s=" i liked ti move it move it";
        String arr[]=s.split(" ");
        System.out.println(Arrays.toString(arr));
    }
}
