package day23inheritance;

public class Bus extends Motorized{

          public Bus(int numOfPassenger){
              super(35);
            System.out.println("Bus Constructor  With Integer  parameter");

    }
}
