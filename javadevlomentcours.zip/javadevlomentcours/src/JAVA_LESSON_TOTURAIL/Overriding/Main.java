package JAVA_LESSON_TOTURAIL.Overriding;

public class Main {

    public static void main(String[] args) {

    A obj1=new A();
    obj1.display();
    System.out.println(obj1.i);

    A obj2=new B();
        System.out.println(obj2.i);
    obj2.display();





    }
}
