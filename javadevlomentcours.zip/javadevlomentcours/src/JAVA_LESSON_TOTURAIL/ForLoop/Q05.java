package JAVA_LESSON_TOTURAIL.ForLoop;

public class Q05 {

    public static void main(String[] args) {

        //Write a program to print odd counting numbers from 200 to 33 on the console by using for-loop.
        for (int i=200;i>33;i--){
            if (i%2!=0){
                System.out.println(i+" ");
            }
        }
    }
}
