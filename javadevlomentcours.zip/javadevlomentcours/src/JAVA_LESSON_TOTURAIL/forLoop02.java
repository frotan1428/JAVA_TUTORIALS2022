package JAVA_LESSON_TOTURAIL;

public class forLoop02 {
    public static void main(String[] args) {

        //1.Example: Type code to print 5 times "Hello!" on the console
        String st="Hello!";
        for (int i=1; i<5; i+=1){
            System.out.println(st);
        }

    }
}
