package JAVA_LESSON_TOTURAIL.Overriding;

public class A {
    int i=11;
    public void display(){
        System.out.println(i);
    }
}
