package JAVA_LESSON_TOTURAIL.Inheritance;

public class Son2Boy extends Son2{
}
