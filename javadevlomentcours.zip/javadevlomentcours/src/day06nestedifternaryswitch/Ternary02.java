package day06nestedifternaryswitch;

public class Ternary02 {
    public static void main(String[] args) {

        //Write a program to print the minimum of 2 integers on the console. Use ternary...
        // syntax:// 1-Condition 2-Question mark 3-:Result for happy scenario 4-colon:  5-negative scenario;
        int  a=100;
        int b=100;
        int min =a<b  ? a:b;
        //Note:Second result wi be appears

        System.out.println(min);
    }
}
