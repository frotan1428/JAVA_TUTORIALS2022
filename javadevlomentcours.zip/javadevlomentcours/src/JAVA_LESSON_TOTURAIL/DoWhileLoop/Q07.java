package JAVA_LESSON_TOTURAIL.DoWhileLoop;

public class Q07 {
    public static void main(String[] args) {

        //Write a program to print numbers from 10 to 3 on the console by using do-while loop.


        int i=10;

        do {
            System.out.println(i+" ");
            i--;
        }while (i>2);
    }
}
