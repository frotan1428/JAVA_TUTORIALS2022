package day28Abstraction;

public abstract class abstractTrial {


    public abstract int sum();

    public void sound(){


    }
}
