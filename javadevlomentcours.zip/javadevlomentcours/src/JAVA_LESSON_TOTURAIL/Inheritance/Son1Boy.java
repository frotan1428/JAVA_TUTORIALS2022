package JAVA_LESSON_TOTURAIL.Inheritance;

public class Son1Boy extends Son1{
}
