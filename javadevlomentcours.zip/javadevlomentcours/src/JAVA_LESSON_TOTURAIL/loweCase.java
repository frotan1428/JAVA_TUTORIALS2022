package JAVA_LESSON_TOTURAIL;

import java.util.Scanner;

public class loweCase {

        public static void main(String[] args) {

            System.out.println("Please Enter any String");
            Scanner scan = new Scanner(System.in);
            String st1 = scan.next().toLowerCase();
            System.out.println("This is Lowe Case Letter:" + st1);


        }
}
