package day21varargsstringbulideraccessmodifires;

public class Parent {

    protected String illness="Anorexia";

}
