package JAVA_LESSON_TOTURAIL.IfElseStatements;

public class Q06 {
    public static void main(String[] args) {


        int age=12;

        if (age>20){
            System.out.println("boy");
        }else{
            System.out.println("Man");
        }if (age<20){
            System.out.println("Girl");
        }else{
            System.out.println("women");
        }
    }
}
