package JAVA_LESSON_TOTURAIL;

import day21varargsstringbulideraccessmodifires.StringBuilder01;

public class StringBuilder {
    public StringBuilder(int i) {
    }

    public static void main(String[] args) {

    }



}
