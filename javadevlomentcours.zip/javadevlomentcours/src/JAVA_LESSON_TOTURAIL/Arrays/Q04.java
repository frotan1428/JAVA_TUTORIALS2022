package JAVA_LESSON_TOTURAIL.Arrays;

public class Q04 {

    //How to get the number of elements in an array
    public static void main(String[] args) {
        int myArrays[]=new int[5];

        System.out.println(myArrays.length);//5

    }
}
