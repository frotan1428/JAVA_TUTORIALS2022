package day11DoWhileLoopConstructors;

public class Constructor01 {

    public static void main(String[] args) {

       /*
          java knows is class's is a template to create object
          because of that java put "constructor" in every class  as default.
          Default constructor are not visible inside the class.
          Default constructor have no parameter inside parenthesis
        */
        //Not :Constructor name mus  be same  always with class name
        //how to create an object?
        //class name     object name  key word to create object   constructor:default.
        Constructor01     obj1=       new                         Constructor01();//create object.
    }
}
