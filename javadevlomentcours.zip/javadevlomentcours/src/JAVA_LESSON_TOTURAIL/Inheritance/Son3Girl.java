package JAVA_LESSON_TOTURAIL.Inheritance;

public class Son3Girl extends Son3{
}
