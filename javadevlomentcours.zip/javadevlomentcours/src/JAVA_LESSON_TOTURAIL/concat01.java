package JAVA_LESSON_TOTURAIL;

public class concat01 {
    public static void main(String[] args) {

        String str1 = "Learn" + "Java";
        System.out.println(str1);

        String st2="2"+"3";
        System.out.println(st2);

        String st3="lear"+ "java";

        System.out.println(st3);

        String st4="lear "+" java";
        System.out.println(st4);

        String st5="lear" +" " +"java";
        System.out.println(st4);

        String st6=2+3+"5";
        System.out.println(st6);
        String st7="learn"+2;
        System.out.println(st7);

        String st8= "3A"+(2+3);
        System.out.println(st8);
    }
}
