package JAVA_LESSON_TOTURAIL.DoWhileLoop;

public class Q06 {
    public static void main(String[] args) {

        //Write a program to print numbers from 1 to 5 on the console by using do-while loop.
         int i=1;
        do {
            System.out.println(i+" ");
            i++;
        }while (i<6);
    }
}
