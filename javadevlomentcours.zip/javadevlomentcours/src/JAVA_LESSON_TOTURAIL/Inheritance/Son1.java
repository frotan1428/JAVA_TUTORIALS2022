package JAVA_LESSON_TOTURAIL.Inheritance;

public class Son1 extends Family{

    public void MotorBike(){
        System.out.println("Boy1 And Girl1 need MotorBike");

    }
    public  Son1(){

        System.out.println("Son1 Constructors");
    }
}
