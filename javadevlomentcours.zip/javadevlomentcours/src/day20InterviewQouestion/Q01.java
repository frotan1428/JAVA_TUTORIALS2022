package day20InterviewQouestion;

public class Q01 {

    /*
      Type a program to print the integers from 1 to 100 without using any integer
   */
    public static void main(String[] args) {
        //1.way
        int n='b'-'a';

        System.out.println(n);
        for (int i=n;i<'e'; i++ ){
            System.out.println(i);
        }
        //way
        for (char c='c'/'c';c<'e';c++){

            System.out.println((int)c);
        }

    }
}
