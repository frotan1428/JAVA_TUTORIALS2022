package JAVA_LESSON_TOTURAIL.Review10day;

public class ForLoop02 {

    public static void main(String[] args) {

       // example type code to find the Multiplication of integer from 3 to 5
        int product=1;
        for (int i=3;i<5;i+=1){

            product=product*i;

        }
        System.out.println(product);
    }
}
