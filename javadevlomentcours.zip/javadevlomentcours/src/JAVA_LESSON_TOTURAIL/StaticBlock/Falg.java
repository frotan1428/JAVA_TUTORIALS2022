package JAVA_LESSON_TOTURAIL.StaticBlock;

public class Falg {

    public static void main(String[] args) {
        int arr[]= {3,2,3,3,4,3};
        int count=0;

        for (int i=0; i<arr.length;i++){
            if (arr[i]==3){
                count++;
            }
        }
        System.out.println(count);

    }




}
