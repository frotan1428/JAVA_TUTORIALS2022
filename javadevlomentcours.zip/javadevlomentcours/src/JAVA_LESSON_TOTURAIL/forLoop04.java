package JAVA_LESSON_TOTURAIL;

public class forLoop04 {

    public static void main(String[] args) {

        //4.Example: Type odd integers from 68 to 13 in the same line with a space between consecutive integers
         for (int i=68; i>12; i-=1){
             System.out.print(i+" ");
         }


    }
}
