package JAVA_LESSON_TOTURAIL.Inheritance;

public class Son2 extends Family{

    public  void  bicycle(){

        System.out.println("Son2 and girl2 needed a bicycle");
    }
    public Son2(){
        System.out.println("Son2 Constructors");
    }

}
