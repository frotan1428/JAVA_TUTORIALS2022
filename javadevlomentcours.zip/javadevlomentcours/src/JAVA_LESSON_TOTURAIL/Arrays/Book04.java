package JAVA_LESSON_TOTURAIL.Arrays;

public class Book04 {


    //how to get the size of Array
    public static void main(String[] args) {
        int myArray[]={12,13,14};
        int size=myArray.length;
        System.out.println(size);  //or

        System.out.println(myArray.length);


    }
}
