package JAVA_LESSON_TOTURAIL.Ternary;

public class Q04 {
    public static void main(String[] args) {
        int y=112;
        System.out.println( (y > 5) ? (21) : ("Zebra") );

        System.out.println((y < 91) ? 9 : "Horse");
    }
}
