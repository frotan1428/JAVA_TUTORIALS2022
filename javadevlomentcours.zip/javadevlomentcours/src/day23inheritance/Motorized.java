package day23inheritance;

public class Motorized extends Vehicle{

    public Motorized(int capacity){
        super("Be Carefully");
        System.out.println("Motorized Constructor  with integer  parameter");
    }
}
