package JAVA_LESSON_TOTURAIL.DoWhileLoop;

public class Q01 {
    public static void main(String[] args) {

        //print 1-10 using while Loop
        int i=1;
        do {
            System.out.println(i+"");
            i++;
        }while (i<11);
    }
}
