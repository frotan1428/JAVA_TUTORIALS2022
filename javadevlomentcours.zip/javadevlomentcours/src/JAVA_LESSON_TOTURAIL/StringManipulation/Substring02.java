package JAVA_LESSON_TOTURAIL.StringManipulation;

public class Substring02 {

    public static void main(String[] args) {

        String str = "Cat, caterpillar";

        String str6= str.substring(5,8);
        String str7 = str.substring(5,8);
        System.out.println(str7); //cat
    }
}
