package day20InterviewQouestion;

public class TQ06 {
    public static void main(String[] args) {

        //Write a Java Program to swap two numbers
        int a =12;
        int b=10;

        //a=10
        //b=12

        int c = 0;

        c = a; //c = 12

        a=b;  //a=10

        b = c; // b = 12

        System.out.println("a: " + a);
        System.out.println("b: " + b);
    }
}
