package paractice04;

public class StringToCharArray {

    public static void main(String[] args) {



    }
}
