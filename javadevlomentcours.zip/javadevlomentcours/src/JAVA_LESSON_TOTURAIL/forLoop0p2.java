package JAVA_LESSON_TOTURAIL;

public class forLoop0p2 {
    public static void main(String[] args) {

        //1) Write a program to print counting numbers from 10 to 57 on the console by using for-loop.

        for (int i=10; i<57; i+=1){
            System.out.print(i+ " ");
        }
    }
}
