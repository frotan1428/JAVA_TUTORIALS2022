package JAVA_LESSON_TOTURAIL.Inheritance;

public class Son3Boy extends Son3 {

}
