package JAVA_LESSON_TOTURAIL;

public class forLoop0p7 {
    public static void main(String[] args) {

        //Write a program to print counting numbers which are less than 200 and divisible by 5
        //On the console by using for-loop.

        for (int i =1;i<200; i+=1){
            if (i%5==0){
                System.out.println(i+ " ");
            }
        }
    }
}
