package JAVA_LESSON_TOTURAIL;

public class forLoop0p3 {
    public static void main(String[] args) {

        //Write a program to print even counting numbers from 100 to 43 on the console by using for-loop.

        for (int i=100; i>42; i-=1){

            if (i%2==0){
                System.out.print(i+ " ");
            }
        }
    }
}
