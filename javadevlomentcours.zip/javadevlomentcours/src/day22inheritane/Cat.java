package day22inheritane;

public class Cat extends Mammals{

    public void meow(){
        System.out.println("Cats meow...");
    }

}

