package JAVA_LESSON_TOTURAIL.WhileLoop;

public class B {

    public B(){
       super();
    }
}
