package JAVA_LESSON_TOTURAIL.Ternary;

public class Q02 {
    public static void main(String[] args) {

        int y = 10;
        int x = (y > 5) ? (2 * y) : (3 * y);
        System.out.println(x);
    }
}
