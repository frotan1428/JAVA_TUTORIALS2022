package day23inheritance;

public class Bicycle extends Vehicle{

    public Bicycle(String make){

        System.out.println("Bicycle Constructor  with  parameter");


    }
}
