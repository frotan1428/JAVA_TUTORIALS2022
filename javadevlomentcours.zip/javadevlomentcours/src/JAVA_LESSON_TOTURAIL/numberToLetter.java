package JAVA_LESSON_TOTURAIL;

import java.util.Scanner;

public class numberToLetter {
    public static void main(String[] args) {

        Scanner scan=new Scanner(System.in);
        System.out.println("please Enter any ");
    }
}
