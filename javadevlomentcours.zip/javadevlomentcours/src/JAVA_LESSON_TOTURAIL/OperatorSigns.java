package JAVA_LESSON_TOTURAIL;

public class OperatorSigns {

    public static void main(String[] args) {

        //   1) = —> Assignment Operator in Java
          int num1 = 12;
          boolean isOld = true;
        //  2) = = —> Equal Sign or Comparison Operator in java
           boolean isTrue = 5 + 2 == 7;
           boolean isFalse = 13 + 4 == 71;
        //  3) != —> Not Equal Sign in java
            boolean isFalse1 = 13 + 4 != 71;
            boolean isTrue2 = 5 + 2 != 7;
         // 4) “>” —> “Greater than” sign in java
            boolean ist=12>10;
        //  5) “<” —> “less than” sign in java
        boolean ist2=12<10;
        //  6) “>=” —> “greater  than or equal to” sign in java
        boolean isTrue3 = 12 >= 13;
        boolean isTrue4 = 12 >= 12;
        //  7) “>=” —> “greater  than or equal to” sign in java
        boolean isTrue5 = 12 <= 13;
        boolean isTrue6 = 12 <= 12;





    }
}
