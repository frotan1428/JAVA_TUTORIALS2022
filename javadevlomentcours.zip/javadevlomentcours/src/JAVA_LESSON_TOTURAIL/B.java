package JAVA_LESSON_TOTURAIL;

class B extends C{
    public int x=12;
    public void m(){
        System.out.println("bad");
    }
}
