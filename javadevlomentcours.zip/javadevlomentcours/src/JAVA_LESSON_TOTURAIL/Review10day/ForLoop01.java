package JAVA_LESSON_TOTURAIL.Review10day;

public class ForLoop01 {

    public static void main(String[] args) {

        //1.example type code to find the sum of integer from 12 to 231
        int total=0;
        for (int i=12;i<231; i+=1){
            total=total+i;

        }
        System.out.println(total);
    }
}
