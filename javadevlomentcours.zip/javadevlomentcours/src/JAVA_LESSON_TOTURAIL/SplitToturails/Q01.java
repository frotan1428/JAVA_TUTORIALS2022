package JAVA_LESSON_TOTURAIL.SplitToturails;

import java.util.Arrays;

public class Q01 {


    public static void main(String[] args) {


        String st="I Love Java";

        System.out.println(st);

        String arr[]=st.split(" ");
        System.out.println(Arrays.toString(arr));


    }
}
