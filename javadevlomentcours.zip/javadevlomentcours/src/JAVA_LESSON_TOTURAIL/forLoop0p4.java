package JAVA_LESSON_TOTURAIL;

public class forLoop0p4 {
    public static void main(String[] args) {

        // Write a program to print odd counting numbers from 200 to 33 on the console by using for-loop.

        for (int i=200; i>32;i-=1){

            if (i%2!=0){
                System.out.print(i+ " ");
            }
        }
    }
}
