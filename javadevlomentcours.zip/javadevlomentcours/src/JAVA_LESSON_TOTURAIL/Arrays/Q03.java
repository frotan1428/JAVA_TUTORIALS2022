package JAVA_LESSON_TOTURAIL.Arrays;

public class Q03 {

    public static void main(String[] args) {

        int myArrays[]=new int[5];

        myArrays[0]=13;
        myArrays[1]=12;
        myArrays[2]=15;
        myArrays[3]=20;
        myArrays[4]=25;

        //How to print a specific element on the console
        System.out.println(myArrays[2]);//15
        System.out.println(myArrays[0]);//13
        System.out.println(myArrays[4]);//25


    }
}
