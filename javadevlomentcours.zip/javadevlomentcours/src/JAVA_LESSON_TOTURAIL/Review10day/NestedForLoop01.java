package JAVA_LESSON_TOTURAIL.Review10day;

public class NestedForLoop01 {

    public static void main(String[] args) {

        //Example: Type 3 times Hello1 for 1, 3 times Hello2 for 2, 3 times Hello3 for 3, 3 times Hello4 for 4 on the console
        for (int i=1;i<5;i++){

            for (int k=1;k<2;k++){
                System.out.println("Hello" +i);
            }

        }

    }
}
