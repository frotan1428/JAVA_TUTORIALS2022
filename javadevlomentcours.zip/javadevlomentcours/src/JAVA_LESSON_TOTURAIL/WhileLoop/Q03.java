package JAVA_LESSON_TOTURAIL.WhileLoop;

public class Q03 {

        /*
        Type java code by using while loop.
            Write a program that types first 30 consecutive odd integers.
         */
    public static void main(String[] args) {


        int i=1;
        while (i<30){
            System.out.println(i+" ");
            i+=2;
        }

    }
}
