package JAVA_LESSON_TOTURAIL.Review10day;

public class WhileLoop01 {

    public static void main(String[] args) {

        //1.Example: Type code to print "Hello!" 5 times on the console using while Loop.

        int i =1;
         while (i<5){
             System.out.println("Hello");
             i++;
         }



    }
}
