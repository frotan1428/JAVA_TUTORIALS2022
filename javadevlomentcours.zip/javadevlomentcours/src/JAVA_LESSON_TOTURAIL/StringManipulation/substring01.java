package JAVA_LESSON_TOTURAIL.StringManipulation;

public class substring01 {
    public static void main(String[] args) {


        String str = "Cat, caterpillar";
        String str1 = str.substring(0);
        String str2 = str.substring(3);
        String str3 = str.substring(6);
        System.out.println(str3);
    }
}
