package JAVA_LESSON_TOTURAIL.Ternary;public class Constructors {
}
