package JAVA_LESSON_TOTURAIL.DoWhileLoop;

import java.util.Scanner;

public class Q12 {
    public static void main(String[] args) {
        /*
                Ask user to enter a String
                      Print the characters whose indexes are odd on the console
                         For example; Germany ==> e m n



         */
        Scanner scan=new Scanner(System.in);
        System.out.println("Please Enter A String:");
        String str=scan.nextLine();

    }
}
