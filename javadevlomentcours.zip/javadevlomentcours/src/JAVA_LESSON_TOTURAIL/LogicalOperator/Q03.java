package JAVA_LESSON_TOTURAIL.LogicalOperator;

public class Q03 {
    public static void main(String[] args) {

        /*
            ! (true) = false
            ! (false) = true
         */
        if ( !(10 > 7) && 10 > 6 ) {
            System.out.println("Apple");
        } else {
            System.out.println(" Grape");
        }
    }
}
