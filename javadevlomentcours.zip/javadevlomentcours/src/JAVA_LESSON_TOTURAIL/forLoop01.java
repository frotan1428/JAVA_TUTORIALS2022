package JAVA_LESSON_TOTURAIL;

public class forLoop01 {
    public static void main(String[] args) {

        //1.Example: Type code to print 5 times "Hello!" on the console
        System.out.println("Hello!");
        System.out.println("Hello!");
        System.out.println("Hello!");
        System.out.println("Hello!");
        System.out.println("Hello!");

    }
}
