package JAVA_LESSON_TOTURAIL.Arrays;

import java.util.Arrays;

public class Book01 {

    public static void main(String[] args) {


       //int myArray[];  //Declare array
       int  myArray[] = new int[6];
       String srr[]=new String[7];
        System.out.println(Arrays.toString(myArray));

    }
}
