package day23inheritance;

public class Vehicle {

    public Vehicle(){

        System.out.println("Vehicle Constructor  without  parameter");

    }

    public Vehicle(String note){

        System.out.println("Vehicle Constructor  with String  parameter");
    }
}
