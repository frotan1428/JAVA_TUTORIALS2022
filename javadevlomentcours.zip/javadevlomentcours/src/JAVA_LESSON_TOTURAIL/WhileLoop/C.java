package JAVA_LESSON_TOTURAIL.WhileLoop;

public class C {
}
