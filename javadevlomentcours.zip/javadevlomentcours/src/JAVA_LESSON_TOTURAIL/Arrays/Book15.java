package JAVA_LESSON_TOTURAIL.Arrays;

import java.util.Arrays;

public class Book15 {
  //How to print arrays on the console by using toString()
    public static void main(String[] args) {

        int arr3[]={3,2,8,7,11};

        Arrays.sort(arr3);
        System.out.println(Arrays.toString(arr3));

    }
}
