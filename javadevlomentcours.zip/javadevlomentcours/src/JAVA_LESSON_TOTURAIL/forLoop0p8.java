package JAVA_LESSON_TOTURAIL;

public class forLoop0p8 {
    public static void main(String[] args) {

        //Type java code by using for loop.
        //Write a program that types first 30 consecutive odd integers.
        for (int i=1; i<30; i+=1){
            if (i%2!=0){
                System.out.println(i+ " ");
            }
        }

    }
}
