package day05ifeslestaements;

public class ifEslestaements02 {

    public static void main(String[] args) {


        //If we have day time class, I can join it

        //If we have NT class, I can join it


        boolean dt = false; // Not available
        boolean nt = false; // Not available

        //true || true   => true

        //false || true  => true

        //true || false  => true

        //false  || false => false

        if(dt || nt){
            System.out.println("I can join the class");
        }else{
            System.out.println("I CANNOT join the class");
        }





    }
}
