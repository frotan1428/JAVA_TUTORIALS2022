package JAVA_LESSON_TOTURAIL;

public class C {
    public int x=11;
    public void m(){

        System.out.println("Good");
    }



}
