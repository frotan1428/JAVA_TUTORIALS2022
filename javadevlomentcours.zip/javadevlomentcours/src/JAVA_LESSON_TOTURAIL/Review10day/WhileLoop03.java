package JAVA_LESSON_TOTURAIL.Review10day;

public class WhileLoop03 {

    public static void main(String[] args) {

        //Example : Type code to sum from 12 to 67
         int i =12;
         int sum=0;
          while (i<68){

              sum=sum+i;
              i++;
          }
        System.out.println("The sum of 12-67:"+sum);

    }
}
