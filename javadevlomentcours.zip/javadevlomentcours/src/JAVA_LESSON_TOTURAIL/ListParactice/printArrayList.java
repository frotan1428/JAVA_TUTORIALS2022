package JAVA_LESSON_TOTURAIL.ListParactice;

import java.util.ArrayList;

public class printArrayList {
    //How  to print an ArrayList on the console
    public static void main(String[] args) {

        ArrayList<Integer> al1=new ArrayList<>();
        al1.add(12);
        al1.add(10);
        al1.add(15);
        System.out.println(al1);

  //How  to print an ArrayList by Index on the console





    }
}
