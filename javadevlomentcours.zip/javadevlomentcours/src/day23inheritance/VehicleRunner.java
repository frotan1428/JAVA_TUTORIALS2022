package day23inheritance;

public class VehicleRunner {

    public static void main(String[] args) {

        Car car1=new Car("Honda");

        Bus bus1=new Bus(25);

        Bicycle bicycle1=new Bicycle("Nike");
    }
}
