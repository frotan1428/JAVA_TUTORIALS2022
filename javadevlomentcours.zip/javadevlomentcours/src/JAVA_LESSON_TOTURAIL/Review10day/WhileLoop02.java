package JAVA_LESSON_TOTURAIL.Review10day;

public class WhileLoop02 {

    public static void main(String[] args) {
       //Example Type code to print odd integer from 12 to 67 line with Space between them:
         int i=12;
         while (i<68){

             if (i%2!=0)
                 System.out.print(i+ " ");
             i++;
         }


    }
}
