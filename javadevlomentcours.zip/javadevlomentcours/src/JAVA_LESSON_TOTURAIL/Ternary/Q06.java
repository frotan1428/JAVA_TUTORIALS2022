package JAVA_LESSON_TOTURAIL.Ternary;

public class Q06 {
    public static void main(String[] args) {

   int m=10;
   int n=2;
   int sum=0;
   while (m>n){
       m--;
       n=n+2;
       sum=sum+m+n;

   }
        System.out.println(sum);
    }
}
