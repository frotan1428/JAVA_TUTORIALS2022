package JAVA_LESSON_TOTURAIL;

public class ifStatementQ2 {
    public static void main(String[] args) {
        String st="S";
        /*

        Type java code by using if statement. When you enter the initial of the day of a week,
        output should be all possible names of the days.
        For example; if the initial is ’S’ output should be “Saturday or Sunday”
         */
        if (st=="S"){
            System.out.println("Sunday");
            System.out.println("Saturday");
        }

    }
}
