package JAVA_LESSON_TOTURAIL;

import java.util.Scanner;

public class For01 {

    public static void main(String[] args) {

        int x=6;
        int y=1;

        while (y<11){
            System.out.println(x+"X"+y+"="+x*y);
            y++;
        }

        }

    }

