package JAVA_LESSON_TOTURAIL.Inheritance;

public class Son2Girl extends Son2{
}
