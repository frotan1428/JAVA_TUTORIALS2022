package paractice03;

import java.lang.reflect.Array;
import java.util.Arrays;

public class Q05 {

    public static void main(String[] args) {

        char arr[]= new  char[4];
        arr[0]='A';
        arr[1]='A';
        arr[2]='A';
        System.out.println(Arrays.toString(arr));

    }

}
