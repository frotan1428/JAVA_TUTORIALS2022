package JAVA_LESSON_TOTURAIL.StringManipulation;

public class Trim {
    public static void main(String[] args) {


     String st="  ALi Can";
        System.out.println(st.trim());
    }
}
