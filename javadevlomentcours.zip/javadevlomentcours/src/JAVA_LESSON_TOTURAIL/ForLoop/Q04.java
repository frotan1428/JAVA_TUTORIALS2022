package JAVA_LESSON_TOTURAIL.ForLoop;

public class Q04 {


    //Write a program to print even counting numbers from 100 to 43 on the console by using for-loop.
    public static void main(String[] args) {

        for (int i=100;i>43;i--){

            System.out.println(i+" ");
        }
    }
}
