package day28Abstraction;

public class CarRunner {

    public static void main(String[] args) {
        // reference    object
           /*
           Car car=new  Toyota();
           car.make();
           car.model();
           car.year();
            */

        Car car2=new Honda();
        car2.make();
        car2.model();
        car2.year();


    }
}
