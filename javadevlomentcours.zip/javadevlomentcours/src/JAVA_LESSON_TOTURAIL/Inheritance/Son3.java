package JAVA_LESSON_TOTURAIL.Inheritance;

public class Son3 extends Family{

    public void  Car(){
        System.out.println("Son3 boy 3 needed A car");
    }

    public Son3(){
        System.out.println("Son3 Constructors");
    }

}
