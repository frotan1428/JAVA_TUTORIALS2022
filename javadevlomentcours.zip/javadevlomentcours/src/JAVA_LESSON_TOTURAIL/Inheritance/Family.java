package JAVA_LESSON_TOTURAIL.Inheritance;

public class Family {

    public  void Money(){
        System.out.println("Every Boy and Child Need Money");
    }

    public Family(){
        System.out.println("Family Constructors");
    }
}
